import os
import telebot

TOKEN = os.getenv("BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "أهلاً! أرسل لي رابط وسأحمله لك.")

@bot.message_handler(func=lambda message: True)
def download_link(message):
    bot.reply_to(message, "جارٍ تحميل الرابط: " + message.text)

bot.infinity_polling()